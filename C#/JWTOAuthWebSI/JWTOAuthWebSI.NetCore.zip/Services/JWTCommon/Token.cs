﻿namespace EZOper.TechTester.JWTOAuthWebSI.Services.JWTCommon
{
    public class Token
    {
        public string access_token { get; set; }
        public string expires_in { get; set; }
        public string token_type { get; set; }
    }
}
