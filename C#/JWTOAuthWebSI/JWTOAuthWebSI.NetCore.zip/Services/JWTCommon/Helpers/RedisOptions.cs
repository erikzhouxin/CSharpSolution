﻿namespace EZOper.TechTester.JWTOAuthWebSI.Services.JWTCommon
{
    public class RedisOptions
    {
        public string MasterServer { get; set; }
        public string SlaveServer { get; set; }
    }
}
